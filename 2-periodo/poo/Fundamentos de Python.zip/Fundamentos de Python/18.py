nota = float(input('Nota: '))
if nota < 7:
    print('Insuficiente')
elif nota == 7:
    print('Média')
else:
    print('Excelente')