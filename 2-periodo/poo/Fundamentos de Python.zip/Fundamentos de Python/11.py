nome = input('Nome: ')
idade = int(input('Idade: '))  
altura = float(input('Altura: '))

print('Tipo de nome:', type(nome))
print('Tipo de idade:', type(idade))
print('Tipo de altura:', type(altura))