nome = input('Nome: ')

if 'e' in nome:
    print(f'Olá, {nome}, seu nome contém a letra "e"!')
else:
    print(f'Olá, {nome}, seu nome NÃO contém a letra "e"!')