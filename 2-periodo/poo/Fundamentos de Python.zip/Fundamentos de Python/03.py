nome = input('Digite seu nome: ')
sobrenome = input('Digite seu sobrenome: ')

print(f'Seu nome completo é {nome} {sobrenome}')
print('Seu nome completo é {} {}'.format(nome, sobrenome))
print('nome 3', nome + ' ' + nome + ' ' + nome)