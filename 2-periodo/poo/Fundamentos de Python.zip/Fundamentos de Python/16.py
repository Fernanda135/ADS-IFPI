cliente = 'João'
preco = 1500.00

print('O cliente {} comprou uma bicicleta por R$ {:.2f}'.format(cliente, preco))