x = 20
y = 5

print('Divisão com /:', x / y)
print('Divisão com //:', x // y)
print('Resto da divisão com %:', x % y)