nome = input('Digite seu nome: ')
sobrenome = input('Digite seu sobrenome: ')

print('Seu nome completo é', nome + ' ' + sobrenome)
print('nome 3', nome + ' ' + nome + ' ' + nome)