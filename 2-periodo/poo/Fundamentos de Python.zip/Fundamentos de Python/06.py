numero = int(input("Número: "))

if numero > 10:
    print("Maior que 10")
elif numero == 0:
    print("Zero")
elif numero % 2 == 0:
    print("Divisível por 2")