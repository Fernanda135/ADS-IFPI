nome = "Ana"
idade = 28

frase = "Meu nome é " + nome + " e eu tenho " + str(idade) + " anos."
print(frase)

frase = f"Meu nome é {nome} e eu tenho {idade} anos."
print(frase)