nome = input('Nome: ')

print('Nome começa com a letra A?', nome[0].upper() == 'A')