numero = int(input("Número: "))
if numero % 2 == 0:
    print(f"{numero} é par")
else:
    print(f"{numero} é ímpar")