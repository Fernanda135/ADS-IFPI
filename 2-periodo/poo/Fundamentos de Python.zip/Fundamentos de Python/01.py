x = int(input('x = '))
y = float(input('y = '))

soma = x + y
subtracao = x - y
multiplicacao = x * y
divisao = x / y

print('soma =', soma)
print('subtracao =', subtracao)
print('multiplicacao =', multiplicacao)
print('divisao =', divisao)

print('tipo de x =', type(x))
print('tipo de y =', type(y))