public interface Forma {

    double perimetro();
    double area();

}
