class Normal extends Ingresso {

    Normal(double valor) {
        super(valor);
    }

    void tipoIngresso() {
        System.out.println("Ingresso Normal");
    }
}
