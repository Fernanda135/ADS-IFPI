public abstract class Animal {

    String nome;
    int idade;

    public void emitirSom() {
        System.out.println("Som do animal");
    }

}
