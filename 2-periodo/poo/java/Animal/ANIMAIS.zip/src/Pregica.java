public class Pregica extends Animal {

    @Override
    public void emitirSom() {
        System.out.println("Som da preguiça..");
    }
}
