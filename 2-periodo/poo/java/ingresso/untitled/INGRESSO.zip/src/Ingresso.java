class Ingresso {

    double valor;

    Ingresso(double valor) {
        this.valor = valor;
    }

    void imprimeValor() {
        System.out.println("Valor do ingresso: R$" + valor);
    }

}
